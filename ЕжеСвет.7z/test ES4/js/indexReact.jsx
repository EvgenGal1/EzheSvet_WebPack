import '../styles/scss/style';

// export default class IndexReact {}