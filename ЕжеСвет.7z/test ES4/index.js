// import IndexReact from "./js/indexReact.jsx";
import './styles/css/style.css';
// import './styles/scss/style.scss';

// console.log(IndexReact)